import java.io.*;
public class AirlineReservationSystem {

    public static void main(String args[]) throws IOException {
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    
    String user, password, yn, search, again, choice;
    int to=0, y=1, z=0, end=0, r=1;
    int available[] = new int[6];
    int ticketI[][] = new int [100][3];
    String ticketS[][] = new String[100][3];
    double ticketD[][] = new double [100][3];
    double pay[] = new double[20];
    double change[] = new double[20];
    
    for(int i=1;i<4;){
		System.out.print("Enter User: ");
		user = in.readLine();
		System.out.print("Enter Password: ");
		password = in.readLine();
    
    	//store 300 seats every destination [1-5]//
    	for(int o=1; o<=5; o++){
    		available[o]=300;
  		}
    
    	//If user and password credentials are correct, proceed to main menu//
    	if(user.equals("1") && password.equals("1")){ 	
    		for(int x=1; x==1;){
    			//MAIN MENU//
    			System.out.println("============================================");
    			System.out.println("||                                        ||");
				System.out.println("||           WELCOME TO LATA!             ||");
				System.out.println("||   [  Lipad Ako Tweng Airlines   ]	  ||");
                System.out.println("||   [ Airline Reservation System  ]	  ||");           		
				System.out.println("||                                        ||");				
    			System.out.println("============================================");
				System.out.println("||                                        ||");
				System.out.println("|| [1] Check Destination                  ||");
    			System.out.println("|| [2] Reserve Ticket                     ||");
    			System.out.println("|| [3] Verify/Pay Ticket                  ||");
    			System.out.println("|| [4] View Ticket                        ||");
    			System.out.println("|| [5] Exit Program                       ||");
    			System.out.println("||                                        ||");
				System.out.println("============================================");
				System.out.println("============================================\n");
    	
    			for(x=1; x==1;){
					System.out.print("ENTER CHOICE: ");
					choice=in.readLine();
			
					//if CHOICE is "1" display the DESTINATION//
					if (choice.equals("1")){
						System.out.println("=============================================");
    					System.out.println("||   DESTINATION   |  FARE   |    SEATS    ||");
    					System.out.println("=============================================");
    					System.out.println("|| 1. Manila       | Php2500 |     "+available[1]+"     ||");
    					System.out.println("|| 2. Legazpi      | Php1700 |     "+available[2]+"     ||");
    					System.out.println("|| 3. Cebu         | Php1500 |     "+available[3]+"     ||");
    					System.out.println("|| 4. Palawan      | Php2000 |     "+available[4]+"     ||");
    					System.out.println("|| 5. Davao        | Php2500 |     "+available[5]+"     ||");
    					System.out.println("=============================================");
    					System.out.println("=============================================\n");
    					//System.out.println("PWD, STUDENT, & SENIOR CITIZEN with 20% DISCOUNT!!!\n");	
    					x=0;
					}
					
					//if CHOICE is "2" proceed to Ticket Booking//
					else if (choice.equals("2")){
						int print=1;		
						
						//display first the Destination Details//
						System.out.println("============================================");
    					System.out.println("||   DESTINATION   |  FARE   |    SEATS    ||");
    					System.out.println("============================================");
    					System.out.println("|| 1. Manila       | Php2500 |     "+available[1]+"     ||");
    					System.out.println("|| 2. Legazpi      | Php1700 |     "+available[2]+"     ||");
    					System.out.println("|| 3. Cebu         | Php1500 |     "+available[3]+"     ||");
    					System.out.println("|| 4. Palawan      | Php2000 |     "+available[4]+"     ||");
    					System.out.println("|| 5. Davao        | Php2500 |     "+available[5]+"     ||");
    					System.out.println("============================================");
    					System.out.println("============================================\n");
    					
    					if((available[1]==0)&&(available[2]==0)&&(available[3]==0)&&(available[4]==0)&&(available[5]==0)){
    						System.out.println("Sorry, We don't  have available seats for all Destination!");
    						x=0;					
    					}
    					
    					
    					
    					//inputting of Passenger's Name//
    					else{
    					for(x=1; x==1;){
    						System.out.print("\nEnter Passenger's Name: ");
    						ticketS[z][0] = in.readLine();
							
							x=0;
							
							//if Passenger's Name already used, display error and go back to Inputing//
    						for(int l=0; l<z; l++){
    							if(ticketS[l][0].equalsIgnoreCase(ticketS[z][0])){
    								System.out.println("Sorry, Passenger's name have already used!");
    								x=1;
    							}
    						}
    					}
    					
    					//inputing of Destination//
    					//integers Only [1-5]//
    					for(x=1; x==1;){
    						System.out.print("Enter Destination Place: ");
    						to = Integer.parseInt(in.readLine());
    						
    						//if Inputed integers are "<1" or ">5", display error and go back to Inputing//
    						if(to<1 || to>5){
    							System.out.println("Invalid Input!");
    							x=1;
    						}
    						//if available seat is eqaul to "Zero", display error and go back to Inputing//
    						for(int d=1; d<=5; d++){
    							if(to==d){
    								if(available[to]==0){
    									System.out.println("Sorry, We don't have available seat!");
    									x=1;
    								}
    								x=0;
    							}
    						}
    					}
    					
    					//convert the integer to string//
    					String dest[] = { " ", "Manila", "Legazpi", "Cebu", "Palawan", "Davao"};
    					double fare[] = { 0,2500,1700,1500,2000,2500};
    		
    					//converted integer to string, transfer to storage array//
    					ticketS[z][1] = dest[to];
    					ticketD[z][0] = fare[to];
    					
    					//inputing for Number of Passenger's//
    					for(x=1; x==1;){
    					System.out.print("How many passengers are you?: ");
    					ticketI[z][0] = Integer.parseInt(in.readLine());
    		
    						//subtract the available seat by the the number inputed//
    						for(int p=1; p<=5; p++){
    							if(to==p){
    								print=1;
    								available[to] = available[to]-ticketI[z][0];
    								
    								//if the subtracted available seat is "<0", display error//
    								//add the inputed number to the subtracted seat, to back the original seat//
    								//display the available seat and back to the inputing//
    								if(available[to]<0){
    									System.out.print("Sorry, We don't have seat available for " +ticketI[z][0] +" person\n");
    									available[to] = available[to]+ticketI[z][0];
    									System.out.print("We only have " +available[to] +" seat available\n");
    									x=1;
    									print=0;
    								}
    								else{
    									x=0;
    								}
    							}
    						}
    		
    					}
    					/*
    					//inputing for Number of Discounted Passenger's//
    					for(x=1;x==1;){
    						System.out.print("HOW MANY PASSENGERS HAVE DISCOUNT?: ");
    						ticketI[z][1] = Integer.parseInt(in.readLine());
    					
    						if(ticketI[z][1]>ticketI[z][0]){
    							
    							System.out.println("Invalid Input!");
    							System.out.println("No. of Passengers are only " +ticketI[z][0] +"!");
    						x=1;
    						}
    						else{
    							break;
    						}
    					}
    		*/
    		
    					//print out of passengers details....
    					if(print==1){
    						System.out.println("\n=======================================");
    						System.out.println("==        PASSENGER'S DETAILS        ==");
    						System.out.println("=======================================");
    						System.out.println("Passenger's Name: " + ticketS[z][0]);
    						System.out.println("Passenger's Destination : " + ticketS[z][1]);
    						System.out.println("Fare Price: Php " + ticketD[z][0]);
    						System.out.println("No. of Passengers: " + ticketI[z][0]);
    					//	System.out.println("NO. OF PASSENGERS WITH DISCOUNT: " + ticketI[z][1]);
    						System.out.println("=======================================");
    						System.out.println("=======================================\n");
    						ticketS[z][2]="0";
    						double discount=(ticketD[z][0]-(ticketD[z][0]*0.2))*ticketI[z][1];
    						ticketD[z][2]= ((ticketI[z][0]-ticketI[z][1])*ticketD[z][0])+discount;
    						x=0;
    					}
    					z++;
    					}
					}
					
					else if (choice.equals("3")){
			          
			            
						for(x=1; x==1;){
							
								System.out.print("Enter Passenger's Name: ");
								search = in.readLine();
								
								
								int s=1;
								for(int b=0;b<z;b++){
									if(search.equalsIgnoreCase(ticketS[b][0])){
										System.out.println("=======================================");
	    								System.out.println("==        PASSENGER'S DETAILS        ==");
	    								System.out.println("=======================================");
	    								System.out.println("Passenger's Name: " + ticketS[b][0]);
	    								System.out.println("Passenger's Destination : " + ticketS[b][1]);
	    								System.out.println("Fare Price: Php" + ticketD[b][0]);
	    								System.out.println("No. of Passengers: " + ticketI[b][0]);
	    					//			System.out.println("NO. OF PASSENGERS WITH DISCOUNT: " + ticketI[b][1]);
		 		   						System.out.println("=======================================");
	    								System.out.println("=======================================");
	    								s=0;
										x=0;
										
										if(ticketS[b][2].equals("x")){
	    									System.out.println("Passenger's Already Paid!");
	    									x=0;
	    								}
	    								else{
	    									ticketS[b][2]="x";
	    									
	    								
	    									for(x=1; x==1;){
	    										System.out.println("\nPassenger's Total fare: Php "+ticketD[b][2]);
	    										System.out.print("Enter Amount to Pay: ");
	    										pay[b] = Double.parseDouble(in.readLine());
	    										change[b]=pay[b]-ticketD[b][2];
	    							
	    										if(change[b]<0){
	    											System.out.println("Invalid Input!");
	    											x=1;
	    										}
	    										else{
	    											System.out.println("Change: Php "+change[b]);
	    											System.out.println("");
	    											x=0;
	    										}
	    									}
										}
									}
								}
								if (s==1){
									System.out.println("\nPassenger's Name Not Found!\n");
									for(int q=1; q==1;){
									
									System.out.print("Do you wish to continue with this transaction? [Y/N]: ");
									again=in.readLine();
									
									if(again.equalsIgnoreCase("y")){
										q=0;
									}
									else if (again.equalsIgnoreCase("n")){
										q=0;
										x=0;
										
									}
									else{
										System.out.println("\nInvalid input!\n");
									}
								
						
								}
							}	
						}
			            
					}
					
					else if (choice.equals("4")){
						
						
						for(int sx=1; sx<=3;){
 						System.out.print("Search Passenger's Name: ");
    					search = in.readLine();
    		    
    		 		   	int s=1;
							for(x=0; x<=z; x++){
								if(search.equalsIgnoreCase(ticketS[x][0])){
									System.out.println("=======================================");
    								System.out.println("==        PASSENGER'S DETAILS        ==");
    								System.out.println("=======================================");
    								System.out.println("Passenger's Name: " + ticketS[x][0]);
    								System.out.println("Passenger's Destination : " + ticketS[x][1]);
    								System.out.println("Fare Price: Php" + ticketD[x][0]);
    								System.out.println("No. of Passengers: " + ticketI[x][0]);
    						//		System.out.println("NO. OF PASSENGERS WITH DISCOUNT: " + ticketI[x][1]);
    								System.out.println("Total Fare Price: Php " + ticketD[x][2]);
    								if(ticketS[x][2].equals("x")){
    									System.out.println("Pay: Php " +pay[x]);
    									System.out.println("Change: Php " +change[x]);
    									System.out.println("Status: Paid");
    								}
    								else{
    									System.out.println("Status: Not Paid");
    								}
    								System.out.println("=======================================");
    								System.out.println("=======================================");
    								s=0;
								    sx=4;
								}
							}	
						
							
							if (s==1){
								System.out.println("Passenger's Name not found!");
								sx++;
							}
							
				    	}
					}		
					
					else if(choice.equals("5")){
						end=1;
						x=0;
						System.out.println("Thank You!");
					}
				
					else{
						System.out.println("Invalid Input!");
						x=1;
					}
    			}
    	
    			for(y=1; y==1;){
    				if(end==1){
    					break;
    				}
    				System.out.print("Do you want another transaction? [Y/N]: ");
   				 	yn = in.readLine();
    	
    				if (yn.equalsIgnoreCase("y")){
    					x=1;
    					y=0;
    				}
    				else if (yn.equalsIgnoreCase("n")){
    					System.out.println("\nThank You!!!");
    					break;
    				}
    				else{
    					System.out.println("Invalid Input!!!");
    					y=1;
    				}
    			}
    		}
    		i=4;
    	}
    	else{
    		System.out.println("\nInvalid user or password!\n");
    		i++;
		}
	
    }
    
    }
    
    
}