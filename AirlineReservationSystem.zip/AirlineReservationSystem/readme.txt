PLEASE READ THIS FIRST

How to open this java file?

1. Open cmd.
2. Change the directory where the folder located. E.G: 'cd Desktop'
3. After changing the directory, Type 'javac NameOfYourProject.java'
4. Next, 'java NameOfYourProject'


Credentials:
username: 1
password: 1

